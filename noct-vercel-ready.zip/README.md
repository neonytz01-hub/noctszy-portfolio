# NOCT — Vercel Ready

This is the English responsive portfolio for Noctszy / NOCT.

## Deploy on Vercel
1. Upload these files to a GitHub repository.
2. Open Vercel and choose "Add New → Project".
3. Import the GitHub repository.
4. Click Deploy.
5. No build command is required.

## Files
- index.html — website structure
- style.css — responsive visual design
- script.js — subtle project hover interaction
- vercel.json — Vercel configuration

The project placeholders can be replaced with your artwork later.
